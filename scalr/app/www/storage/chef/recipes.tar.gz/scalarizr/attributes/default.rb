default[:scalarizr][:behaviour] = [ "base" ]
default[:scalarizr][:platform]  = "ec2"
default[:scalarizr][:branch] = ""